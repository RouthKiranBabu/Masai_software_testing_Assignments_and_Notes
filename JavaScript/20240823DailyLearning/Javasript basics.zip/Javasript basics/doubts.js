// //         // 0 1 2 3 4 
// // //splice 
// // // it will perform the manipulation on the original array or the old array
// // array.splice(0,2,"Addeditem1", "AddedItem2");
// // // array.splice(startIndex, count of the element which we want to remove, the particula element which we want to add instead of the previous one)
// // // it will change the original old array 
// // console.log(array);

// let array=[11,22,33,44,55]

// array.push("AddevalueAtEND");
// let removedItem=array.pop(); // remove the value at the last index
// console.log(removedItem);
// console.log(array);
// array.unshift("AddedItemATstart");
// console.log(array);
// array.shift();
// console.log(array);




// // //slice 
// // let sliceArray=array.slice(2,4) //without including of the last index
// // // it will create a copy of my array
// // console.log(array);
// // // start // end index
// // console.log(sliceArray);



 
let num= 345; // this number into a string
let numString= String(num);
console.log(typeof(numString))

let array=[1,2,3,4,5]
// TO STRING String toString()
let arrStr= array.toString()
console.log(typeof(arrStr))

let todaySdate= new Date()


let str="121"
console.log(str===str.split("").reverse().join(''))