let input= prompt("Enter the value");
// console.log(typeof(input));
// console.log(input)
// document.write(input);