
// let variableName= []
// let arr=[1, 22, 3, 4, 5 , "Divyang"]; 
//arr.length 
// console.log(arr.length);
// // indexing
// // 0
console.log(arr.indexOf(22));
// if value doesn't exit it will give you -1
// address of my particular value 
// for(declare a variable;  range; incerement or decrement)
// for(let i=0; i<=10; i++ ){
//     console.log(i);
// }
// i++ i+=1 i= i+1;
// for(let i=1; i<=10; i+=2){
//     console.log(i);
// }
// // console.log(arr[0]);
// // console.log(arr[1]);
// // console.log(arr[2]);
// // console.log(arr[3]);
// // console.log(arr[4]);

// //string of the js also behaves like an array 

// // for(let index=0; index<arr.length; index++){
// //     console.log(arr[index]);

// // }

// let str="Hello"; 
// let revStr="";
// console.log(str.length);
// for(let index= str.length-1; index>=0; index--){
//     let char= str[index];
//     revStr+=char;

// }
// console.log(revStr);

// let arr= [11 , 27 , 38 ,47 ,50];
// for(let i=0; i<arr.length; i++){ 


// }

// arr.lenth  vs index 

// indexing starts from    0,  1,  2, 3, 4 --> last index  arr.length-1;
// length will start from 11 , 27 , 38 ,47 ,50  --> 5 --arr.length 

//let arr2=[1, 2, 3, 4, 5]; 
// console.log(arr2.length)
// console.log(arr2.indexOf(6));

// element which does not exist -1
// enhanced for 
// for of loop
// let fruits =["Orange", "Grapes", "Banana", "Watermelon"]

// for(let ele of fruits){
//     console.log(ele)
// }

//ignore the ; dont put it anywhere
//for in  to iterate over objects we can for in loop 
//for(let ele in object)

// for(let i=0; i<=5; i+=2){

// }