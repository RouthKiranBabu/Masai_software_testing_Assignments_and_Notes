//Operators- To perform an operation we use operators 
//Operands- Data on which the operations are getting performed 
//var , let , const
//var number=9;

// let j= 9;
// let decimal= 9.5;
// const k="String"
// let a=4; 
// // let a =4; 
// let b=4;

// addition 
// let addSum = a+b;
// console.log(addSum)

// //substraction
// let subSum=b-a;
// console.log(subSum)

// //Multiplication
// let multi= a*b;
// console.log(multi);

// //Division 
// let division= a/b; 
// console.log(division);

// //Modulus 
// let modulus= b%a; 
// console.log(modulus);

// //Exponentiation
// let power= a**3; 
// console.log(power);



// let d= 1; 
// console.log(d--); // printing it out then it is decrementing
// console.log(d);// 0
// let numRandom= 1;
// console.log(--numRandom); //0 increment then it is printing it 
// it will print the result and then it will increment it 
// post increment 

// pre increment
// let c=2;
// console.log(++c);
// // it will first of all increment the result 
// // it will print it 
// console.log(--b);


// let equation = a*(b/c);

// console.log(equation);

// let a= 5; 
// let b=6;
// // relational 
// console.log(b>a); //true  // greater
// console.log(b<a); //false // less than
// console.log(b<=a);// false // less than equal to

//equality
let num =5; // number
let numTwo=6;
let numStr="5"; // String


// console.log(num==numStr);//true // value check even if the data type is different  true
// strict equality 
// console.log(num===numTwo);// false // value is also same and the data type is also same equal


// console.log(num===numStr); // value check and data type check
// //strict equality

// console.log(num!=numStr); //false  //VALUE CHECK 5="5"
// //strict inequality
// console.log(num!==numStr);// true // values 5!=="5" data type is not same 
//let arr=[1,2,3,4, 5, 6]

// example 

for(let i=0; i<=5; i++){

        console.log(i);
}

// 2d array 
//How to iterate over a 2d array