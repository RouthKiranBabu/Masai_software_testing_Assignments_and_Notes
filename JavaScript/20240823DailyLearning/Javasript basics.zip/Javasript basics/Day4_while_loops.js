// // loops
// // Iteration 
// // Repetitive tasks 
// // Reduce our code 
// // Iterate something or execute something repetitive based on condition 


//string concatenation 
// adding of strings 

// let str1= "hello"; 
// let str2="Divyang"
// let str3 = str1+" " +str2;
// console.log(str3);
// string concatenation with number
// let number =5;
// let numString= "5" ; 
// let numberString= number+numString
// console.log(typeof(numString));


// for loop 
//while loop 
//do while loop

//while loop
// limitations
// declaration
// increments
// if we dont know the amount of iteration

// while(condition){ // condition is true the while loop will execute 

// }
//string concatenation

//how to declare the string

// let string= ''; //double quotes 
// let string2=""; //single quotes 
// let string3=``;//back ticks 
// let number=1;
// let str='';
// while(number<=10){ // condition 
//     str=str+" "+number
//     number++// increment
// };
// console.log(str);

//Template literals //ES6 feature 
// let fruit="Orange" ; 
// let numOfFruit=2;
// // let strF= fruit+ numOfFruit;// concatenation
// let strF=  `fruit ${numOfFruit}`
// console.log(strF);

// break statement
// let i=0; 
// let range=10;
// while(i<=range){
//     if(i>5){
//         break; // break will stop the execution of the code 
//     }
//     console.log(i);
//     i++;

// }

// let i=0; 
// let range=10;
// while(i<=range){ //i=0
    
//     if(i%2==0){  // even 
//         i++;
//         continue; 
//     }

//     console.log(i);
//     i++;
// }


// let str="Hello"; 
// let j=str.length-1;
// let str2="";
// while(str.length>0 && j>0){
//     str2+=str[j]
//     j--;    
// }

// let number=10; 

// do{
//     console.log(number)
// }while(number<=10);
// // do while 
// regardless of my condition which i am spacifying
// it will iterate once 
// once one iteration is completed 
// then it will obey the particular condition

