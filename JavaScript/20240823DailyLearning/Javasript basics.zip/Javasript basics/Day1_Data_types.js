
// var num=66;
//  Var is a keyword to declare the variable
// Var is a global scope
// var re-declared and it can be re-assigned 
// var num=77;
// var num=79;
// re declaration 
// console.log(num);

// let name="Divyang";
//redeclaring is not allowed

// let num2=77; 
// let  is a keyword to declare the variable
// let is block scope
// let can be reassigned but not redeclared
// num2=88;
// console.log(num2);

// const num3= 88;
// redeclaration
// num3=99;// reassigning
// const is a keyword to declare the variable
//const is also block scoped
//const cant be reassigned or cant be redeclared 

//Data types
// Number
// String
// Boolean
// BigInt
// Null
// undefined
// symbol

// let number= 1; 
// console.log(typeof(number))
// let decNum= 1.5; 
// console.log(typeof(decNum));
// let str="Hello"; //string
// console.log(typeof(str))
// let boolean =true;// boolean true or false
// console.log(typeof(boolean))
// let bigNum=64474884888888888888888888888888888888888n;
// console.log(typeof(bigNum))
// let symboldata= Symbol("Hello");
// let nullData=null;  // null value its an empty value 
// console.log(typeof(nullData));
// let name;// not defined

//defined 
//null means the value is empty
console.log(typeof(name))

//var , let , const
// lecture context -use let 

// array 
let moinArr= [1, 2, "Divyang"];
//indexing will start from 0